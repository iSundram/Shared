<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 10/08/2022
 */

// Decoded file for php version 72.
$supportedTemplates = [];
$supportedTemplates["emyui"] = ["short" => "emyui", "name" => "Shuffy WHMCS theme (by coodiv)", "file" => "emyui.tpl"];

?>